<?php
/**
 * BuddyPress Forums Actions.
 *
 * @package BuddyPress
 * @subpackage ForumsActions
 * @since 1.5.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
